public String sort_format_names( String s0 )
{
   String s1;
   int i1 , i2;
   s = s0;
   nameptr = 1;
   s0 = "";
   i1 = BuiltIn.numnames( s );
   numnames = i1;
   namesleft = i1;
   while( i1 > 0 )
   {
      if( nameptr > 1 )
      {
         s0 = s0 + "   ";
      }
      s1 = BuiltIn.formatName( s , nameptr , "{vv{ } }{ll{ }}{  ff{ }}{  jj{ }}" );
      t = s1;
      i1 = BuiltIn.equal( numnames , nameptr );
      i2 = BuiltIn.equal( "others" , s1 );
      i1 = and( i1 , i2 );
      if( i1 > 0 )
      {
         s0 = s0 + "et al";
      }
      else
      {
         s1 = sortify( t );
         s0 = s0 + s1;
      }
      nameptr = nameptr + 1;
      i1 = namesleft - 1;
      namesleft = namesleft - 1;
   }
   return( s0 );
}
