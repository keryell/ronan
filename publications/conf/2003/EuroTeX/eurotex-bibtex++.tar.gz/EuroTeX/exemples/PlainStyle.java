package bst;
import bst.BuiltIn;
import auxi.AuxFile;
import bib.*;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Vector;

public class PlainStyle 
{
   private int longest_label_width;
   private int number_label;
   private String longest_label;
   private int len;
   private int multiresult;
   private int numnames;
   private int namesleft;
   private int nameptr;
   private String t;
   private String s;
   private int after_block;
   private int after_sentence;
   private int mid_sentence;
   private int before_all;
   private int output_state;
   private String label;
   private String [] label_tab;
   private String year;
   private String volume;
   private String type;
   private String title;
   private String series;
   private String school;
   private String publisher;
   private String pages;
   private String organization;
   private String number;
   private String note;
   private String month;
   private String key;
   private String journal;
   private String institution;
   private String howpublished;
   private String editor;
   private String edition;
   private String chapter;
   private String booktitle;
   private String author;
   private String address;
   private AuxFile aux;
   private BibFile bib;
   private int global_max , entry_max;
   private String crossref , outputBib="";
   private String sort_key;
   private String [] sort_key_tab;
   public  PlainStyle( AuxFile au , BibFile bi )
   {
      longest_label = "";
      t = "";
      s = "";
      label = "";
      year = "";
      volume = "";
      type = "";
      title = "";
      series = "";
      school = "";
      publisher = "";
      pages = "";
      organization = "";
      number = "";
      note = "";
      month = "";
      key = "";
      journal = "";
      institution = "";
      howpublished = "";
      editor = "";
      edition = "";
      chapter = "";
      booktitle = "";
      author = "";
      address = "";
      aux = au;
      bib = bi;
      Iterator myIterator;
      Vector myVector;
      String id;
      int indice;
      if( System.getProperty( "bib_max" ) == null )
      {
         System.setProperty( "bib_max" , "100" );
      }
      if( System.getProperty("bib_max").compareTo( "" ) == 0 )
      {
         System.setProperty( "bib_max" , "100" );
      }
      entry_max = Integer.parseInt( System.getProperty( "bib_max" ) );
      global_max = Integer.parseInt( System.getProperty( "bib_max" ) );
      bib.addMacro( "jan" , "January" );
      bib.addMacro( "feb" , "February" );
      bib.addMacro( "mar" , "March" );
      bib.addMacro( "apr" , "April" );
      bib.addMacro( "may" , "May" );
      bib.addMacro( "jun" , "June" );
      bib.addMacro( "jul" , "July" );
      bib.addMacro( "aug" , "August" );
      bib.addMacro( "sep" , "September" );
      bib.addMacro( "oct" , "October" );
      bib.addMacro( "nov" , "November" );
      bib.addMacro( "dec" , "December" );
      bib.addMacro( "acmcs" , "ACM Computing Surveys" );
      bib.addMacro( "acta" , "Acta Informatica" );
      bib.addMacro( "cacm" , "Communications of the ACM" );
      bib.addMacro( "ibmjrd" , "IBM Journal of Research and Development" );
      bib.addMacro( "ibmsj" , "IBM Systems Journal" );
      bib.addMacro( "ieeese" , "IEEE Transactions on Software Engineering" );
      bib.addMacro( "ieeetc" , "IEEE Transactions on Computers" );
      bib.addMacro( "ieeetcad" , "IEEE Transactions on Computer-Aided Design of Integrated Circuits" );
      bib.addMacro( "ipl" , "Information Processing Letters" );
      bib.addMacro( "jacm" , "Journal of the ACM" );
      bib.addMacro( "jcss" , "Journal of Computer and System Sciences" );
      bib.addMacro( "scp" , "Science of Computer Programming" );
      bib.addMacro( "sicomp" , "SIAM Journal on Computing" );
      bib.addMacro( "tocs" , "ACM Transactions on Computer Systems" );
      bib.addMacro( "tods" , "ACM Transactions on Database Systems" );
      bib.addMacro( "tog" , "ACM Transactions on Graphics" );
      bib.addMacro( "toms" , "ACM Transactions on Mathematical Software" );
      bib.addMacro( "toois" , "ACM Transactions on Office Information Systems" );
      bib.addMacro( "toplas" , "ACM Transactions on Programming Languages and Systems" );
      bib.addMacro( "tcs" , "Theoretical Computer Science" );
      bib.finishJob( );
      myVector = aux.getCitationVector( );
      indice = 0;
      sort_key_tab = new String[myVector.size( )];
      label_tab = new String[myVector.size( )];
      while( indice < myVector.size( ) )
      {
         sort_key_tab[indice] = "";
         label_tab[indice] = "";
         indice = indice + 1;
      }
      myIterator = aux.getCitationVector( ).iterator( );
      indice = 0;
      while( myIterator.hasNext( ) )
      {
         id = (String) myIterator.next( );
         if( bib.getRef( id ) != null )
         {
            setFields( id , indice );
            presort( );
            saveEntry( indice );
            indice = indice + 1;
         }
         else
         {
            System.err.println( "Warning : can't find citation "+id+" !" );
         }
      }
      BuiltIn.sort( sort_key_tab , aux );
      initialize_longest_label( );
      myIterator = aux.getCitationVector( ).iterator( );
      indice = 0;
      while( myIterator.hasNext( ) )
      {
         id = (String) myIterator.next( );
         if( bib.getRef( id ) != null )
         {
            setFields( id , indice );
            longest_label_pass( );
            saveEntry( indice );
            indice = indice + 1;
         }
         else
         {
            System.err.println( "Warning : can't find citation "+id+" !" );
         }
      }
      begin_bib( );
      init_state_consts( );
      myIterator = aux.getCitationVector( ).iterator( );
      indice = 0;
      while( myIterator.hasNext( ) )
      {
         id = (String) myIterator.next( );
         if( bib.getRef( id ) != null )
         {
            setFields( id , indice );
            callType( id );
            saveEntry( indice );
            indice = indice + 1;
         }
         else
         {
            System.err.println( "Warning : can't find citation "+id+" !" );
         }
      }
      end_bib( );
   }

   public String outputBibliography( )
   {
      return( outputBib );
   }

   private void callType( String id )
   {
      BibRef theRef = bib.getRef( id );
      try
      {
         Method func=this.getClass().getMethod(theRef.getRefType(),null);
         func.invoke(this,null);
      }
      catch(Exception e)
      {
         if( e.getClass( ).getName( ).compareTo( "java.lang.NoSuchMethodException" ) != 0 )
         {
            System.err.println("Error: Exception throw in call to function \""+theRef.getRefType()+"\" in callType().");
            e.printStackTrace();
         }
         else
         {
            System.err.println( "Error : Can't find type "+theRef.getRefType()+" !" );;
         }
      }
   }

   private void setFields( String id , int indice )
   {
      BibRef theRef = bib.getRef( id );
      bib.setCurrentRef( id );
      crossref = "";
      if( theRef.existField( "crossref" ) )
      {
         crossref=(String) theRef.getStringValue("crossref");
      }
      address = "";
      if( theRef.existField( "address" ) )
      {
         address = (String) theRef.getStringValue("address");
      }
      author = "";
      if( theRef.existField( "author" ) )
      {
         author = (String) theRef.getStringValue("author");
      }
      booktitle = "";
      if( theRef.existField( "booktitle" ) )
      {
         booktitle = (String) theRef.getStringValue("booktitle");
      }
      chapter = "";
      if( theRef.existField( "chapter" ) )
      {
         chapter = (String) theRef.getStringValue("chapter");
      }
      edition = "";
      if( theRef.existField( "edition" ) )
      {
         edition = (String) theRef.getStringValue("edition");
      }
      editor = "";
      if( theRef.existField( "editor" ) )
      {
         editor = (String) theRef.getStringValue("editor");
      }
      howpublished = "";
      if( theRef.existField( "howpublished" ) )
      {
         howpublished = (String) theRef.getStringValue("howpublished");
      }
      institution = "";
      if( theRef.existField( "institution" ) )
      {
         institution = (String) theRef.getStringValue("institution");
      }
      journal = "";
      if( theRef.existField( "journal" ) )
      {
         journal = (String) theRef.getStringValue("journal");
      }
      key = "";
      if( theRef.existField( "key" ) )
      {
         key = (String) theRef.getStringValue("key");
      }
      month = "";
      if( theRef.existField( "month" ) )
      {
         month = (String) theRef.getStringValue("month");
      }
      note = "";
      if( theRef.existField( "note" ) )
      {
         note = (String) theRef.getStringValue("note");
      }
      number = "";
      if( theRef.existField( "number" ) )
      {
         number = (String) theRef.getStringValue("number");
      }
      organization = "";
      if( theRef.existField( "organization" ) )
      {
         organization = (String) theRef.getStringValue("organization");
      }
      pages = "";
      if( theRef.existField( "pages" ) )
      {
         pages = (String) theRef.getStringValue("pages");
      }
      publisher = "";
      if( theRef.existField( "publisher" ) )
      {
         publisher = (String) theRef.getStringValue("publisher");
      }
      school = "";
      if( theRef.existField( "school" ) )
      {
         school = (String) theRef.getStringValue("school");
      }
      series = "";
      if( theRef.existField( "series" ) )
      {
         series = (String) theRef.getStringValue("series");
      }
      title = "";
      if( theRef.existField( "title" ) )
      {
         title = (String) theRef.getStringValue("title");
      }
      type = theRef.getRefType( );
      volume = "";
      if( theRef.existField( "volume" ) )
      {
         volume = (String) theRef.getStringValue("volume");
      }
      year = "";
      if( theRef.existField( "year" ) )
      {
         year = (String) theRef.getStringValue("year");
      }
      label = label_tab[indice];
      sort_key = sort_key_tab[indice];
   }

   private void saveEntry( int indice )
   {
      sort_key_tab[indice] = sort_key;
      label_tab[indice] = label;
   }

   public void init_state_consts( )
   {
      before_all = 0;
      mid_sentence = 1;
      after_sentence = 2;
      after_block = 3;
   }

   public String output_nonnull( String s0 , String s1 )
   {
      s = s1;
      if( output_state == mid_sentence )
      {
         outputBib += s0 + ", ";
      }
      else
      {
         if( output_state == after_block )
         {
            s0 = BuiltIn.addPeriod( s0 );
            outputBib += s0;
            outputBib += "\n";
            outputBib += "\\newblock ";
         }
         else
         {
            if( output_state == before_all )
            {
               outputBib += s0;
            }
            else
            {
               s0 = BuiltIn.addPeriod( s0 );
               outputBib += s0 + " ";
            }
         }
         output_state = mid_sentence;
      }
      return( s );
   }

   public String output( String s0 , String s1 )
   {
      if( BuiltIn.empty( s1 ) <= 0 )
      {
         s0 = output_nonnull( s0 , s1 );
      }
      return( s0 );
   }

   public String output_check( String s0 , String s1 , String s2 )
   {
      t = s2;
      if( BuiltIn.empty( s1 ) > 0 )
      {
         s1 = "empty " + t;
         s2 = BuiltIn.cite( bib );
         System.err.println( "Warning : " + s1 + " in " + s2 + "." );
      }
      else
      {
         s0 = output_nonnull( s0 , s1 );
      }
      return( s0 );
   }

   public String output_bibitem( )
   {
      String s0;
      outputBib += "\n";
      outputBib += "\\bibitem{";
      s0 = BuiltIn.cite( bib );
      outputBib += s0;
      outputBib += "}";
      outputBib += "\n";
      output_state = before_all;
      return( "" );
   }

   public void fin_entry( String s0 )
   {
      s0 = BuiltIn.addPeriod( s0 );
      outputBib += s0;
      outputBib += "\n";
   }

   public void new_block( )
   {
      if( output_state != before_all )
      {
         output_state = after_block;
      }
   }

   public void new_sentence( )
   {
      if( output_state != after_block )
      {
         if( output_state != before_all )
         {
            output_state = after_sentence;
         }
      }
   }

   public int not( int i0 )
   {
      if( i0 > 0 )
      {
         i0 = 0;
      }
      else
      {
         i0 = 1;
      }
      return( i0 );
   }

   public int and( Cell c0 , int i1 )
   {
      int i0;
      if( i1 <= 0 )
      {
         c0 = new Cell( 0 );
      }
      i0 = c0.getInt( );
      return( i0 );
   }

   public int or( Cell c0 , int i1 )
   {
      int i0;
      if( i1 > 0 )
      {
         i0 = 1;
      }
      else
      {
         i0 = c0.getInt( );
      }
      return( i0 );
   }

   public void new_block_checka( String s0 )
   {
      if( BuiltIn.empty( s0 ) <= 0 )
      {
         new_block( );
      }
   }

   public void new_block_checkb( String s0 , String s1 )
   {
      int i0 , i1;
      i1 = BuiltIn.empty( s1 );
      i0 = i1;
      i1 = BuiltIn.empty( s0 );
      i0 = and( new Cell( i0 ) , i1 );
      if( i0 <= 0 )
      {
         new_block( );
      }
   }

   public void new_sentence_checka( String s0 )
   {
      if( BuiltIn.empty( s0 ) <= 0 )
      {
         new_sentence( );
      }
   }

   public void new_sentence_checkb( String s0 , String s1 )
   {
      int i0 , i1;
      i1 = BuiltIn.empty( s1 );
      i0 = i1;
      i1 = BuiltIn.empty( s0 );
      i0 = and( new Cell( i0 ) , i1 );
      if( i0 <= 0 )
      {
         new_sentence( );
      }
   }

   public String field_or_null( String s0 )
   {
      if( BuiltIn.empty( s0 ) > 0 )
      {
         s0 = "";
      }
      return( s0 );
   }

   public String emphasize( String s0 )
   {
      if( BuiltIn.empty( s0 ) > 0 )
      {
         s0 = "";
      }
      else
      {
         s0 = "{\\em " + s0 + "}";
      }
      return( s0 );
   }

   public String format_names( String s0 )
   {
      String s1;
      int i0 , i1;
      s = s0;
      nameptr = 1;
      i0 = BuiltIn.numnames( s0 );
      numnames = i0;
      namesleft = i0;
      s0 = BuiltIn.formatName( s0 , 1 , "{ff~}{vv~}{ll}{, jj}" );
      i1 = i0;
      while( i1 > 0 )
      {
         s1 = BuiltIn.formatName( s , nameptr , "{ff~}{vv~}{ll}{, jj}" );
         t = s1;
         if( nameptr > 1 )
         {
            if( namesleft > 1 )
            {
               s0 = s0 + ", " + t;
            }
            else
            {
               if( numnames > 2 )
               {
                  s0 = s0 + ",";
               }
               if( t.compareTo( "others" ) == 0 )
               {
                  s0 = s0 + " et~al.";
               }
               else
               {
                  s0 = s0 + " and " + t;
               }
            }
         }
         nameptr = nameptr + 1;
         i1 = namesleft - 1;
         namesleft = namesleft - 1;
      }
      return( s0 );
   }

   public String format_authors( )
   {
      String s0;
      if( BuiltIn.empty( author ) > 0 )
      {
         s0 = "";
      }
      else
      {
         s0 = format_names( author );
      }
      return( s0 );
   }

   public String format_editors( )
   {
      String s0;
      int i1;
      if( BuiltIn.empty( editor ) > 0 )
      {
         s0 = "";
      }
      else
      {
         s0 = format_names( editor );
         i1 = BuiltIn.numnames( editor );
         if( i1 > 1 )
         {
            s0 = s0 + ", editors";
         }
         else
         {
            s0 = s0 + ", editor";
         }
      }
      return( s0 );
   }

   public String format_title( )
   {
      String s0;
      if( BuiltIn.empty( title ) > 0 )
      {
         s0 = "";
      }
      else
      {
         s0 = BuiltIn.changeCase( title , "t" );
      }
      return( s0 );
   }

   public String n_dashify( String s0 )
   {
      String s1;
      int i1;
      t = s0;
      s0 = "";
      i1 = BuiltIn.empty( t );
      i1 = not( i1 );
      while( i1 > 0 )
      {
         s1 = BuiltIn.substring( t , 1 , 1 );
         if( s1.compareTo( "-" ) == 0 )
         {
            s1 = BuiltIn.substring( t , 1 , 2 );
            i1 = BuiltIn.equal( "--" , s1 );
            i1 = not( i1 );
            if( i1 > 0 )
            {
               s0 = s0 + "--";
               s1 = BuiltIn.substring( t , 2 , global_max );
               t = s1;
            }
            else
            {
               s1 = BuiltIn.substring( t , 1 , 1 );
               i1 = BuiltIn.equal( "-" , s1 );
               while( i1 > 0 )
               {
                  s0 = s0 + "-";
                  s1 = BuiltIn.substring( t , 2 , global_max );
                  t = s1;
                  s1 = BuiltIn.substring( s1 , 1 , 1 );
                  i1 = BuiltIn.equal( "-" , s1 );
               }
            }
         }
         else
         {
            s1 = BuiltIn.substring( t , 1 , 1 );
            s0 = s0 + s1;
            s1 = BuiltIn.substring( t , 2 , global_max );
            t = s1;
         }
         i1 = BuiltIn.empty( t );
         i1 = not( i1 );
      }
      return( s0 );
   }

   public String format_date( )
   {
      String s0 , s1;
      if( BuiltIn.empty( year ) > 0 )
      {
         if( BuiltIn.empty( month ) > 0 )
         {
            s0 = "";
         }
         else
         {
            s1 = BuiltIn.cite( bib );
            System.err.println( "Warning : there's a month but no year in " + s1 + "." );
            s0 = month;
         }
      }
      else
      {
         if( BuiltIn.empty( month ) > 0 )
         {
            s0 = year;
         }
         else
         {
            s0 = month + " " + year;
         }
      }
      return( s0 );
   }

   public String format_btitle( )
   {
      String s0;
      s0 = emphasize( title );
      return( s0 );
   }

   public String tie_or_space_connect( String s0 , String s1 )
   {
      String s2;
      int i2;
      i2 = s1.length( );
      if( i2 < 3 )
      {
         s2 = "~";
      }
      else
      {
         s2 = " ";
      }
      s0 = s0 + s2 + s1;
      return( s0 );
   }

   public void either_or_check( Cell c0 , String s1 )
   {
      String s0;
      if( BuiltIn.empty( s1 ) <= 0 )
      {
         s0 = "can't use both " + c0.getString( );
         s1 = BuiltIn.cite( bib );
         System.err.println( "Warning : " + s0 + " fields in " + s1 + "." );
      }
   }

   public String format_bvolume( )
   {
      String s0 , s1 , s2;
      if( BuiltIn.empty( volume ) > 0 )
      {
         s0 = "";
      }
      else
      {
         s0 = tie_or_space_connect( "volume" , volume );
         if( BuiltIn.empty( series ) <= 0 )
         {
            s1 = emphasize( series );
            s0 = s0 + " of " + s1;
         }
         s2 = number;
         either_or_check( new Cell( "volume and number" ) , s2 );
      }
      return( s0 );
   }

   public String format_number_series( )
   {
      String s0 , s2;
      if( BuiltIn.empty( volume ) > 0 )
      {
         if( BuiltIn.empty( number ) > 0 )
         {
            s0 = field_or_null( series );
         }
         else
         {
            if( output_state == mid_sentence )
            {
               s0 = "number";
            }
            else
            {
               s0 = "Number";
            }
            s0 = tie_or_space_connect( s0 , number );
            if( BuiltIn.empty( series ) > 0 )
            {
               s2 = BuiltIn.cite( bib );
               System.err.println( "Warning : there's a number but no series in " + s2 + "." );
            }
            else
            {
               s0 = s0 + " in " + series;
            }
         }
      }
      else
      {
         s0 = "";
      }
      return( s0 );
   }

   public String format_edition( )
   {
      String s0;
      if( BuiltIn.empty( edition ) > 0 )
      {
         s0 = "";
      }
      else
      {
         if( output_state == mid_sentence )
         {
            s0 = BuiltIn.changeCase( edition , "l" );
            s0 = s0 + " edition";
         }
         else
         {
            s0 = BuiltIn.changeCase( edition , "t" );
            s0 = s0 + " edition";
         }
      }
      return( s0 );
   }

   public int multi_page_check( String s0 )
   {
      int i0 , i1 , i2;
      t = s0;
      multiresult = 0;
      i0 = not( 0 );
      i1 = BuiltIn.empty( s0 );
      i1 = not( i1 );
      i0 = and( new Cell( i0 ) , i1 );
      while( i0 > 0 )
      {
         s0 = BuiltIn.substring( t , 1 , 1 );
         i1 = BuiltIn.equal( "-" , s0 );
         i0 = i1;
         i2 = BuiltIn.equal( "," , s0 );
         i1 = i2;
         i2 = BuiltIn.equal( "+" , s0 );
         i1 = or( new Cell( i1 ) , i2 );
         i0 = or( new Cell( i0 ) , i1 );
         if( i0 > 0 )
         {
            multiresult = 1;
         }
         else
         {
            s0 = BuiltIn.substring( t , 2 , global_max );
            t = s0;
         }
         i0 = not( multiresult );
         i1 = BuiltIn.empty( t );
         i1 = not( i1 );
         i0 = and( new Cell( i0 ) , i1 );
      }
      return( multiresult );
   }

   public String format_pages( )
   {
      String s0 , s1;
      if( BuiltIn.empty( pages ) > 0 )
      {
         s0 = "";
      }
      else
      {
         if( multi_page_check( pages ) > 0 )
         {
            s1 = n_dashify( pages );
            s0 = tie_or_space_connect( "pages" , s1 );
         }
         else
         {
            s0 = tie_or_space_connect( "page" , pages );
         }
      }
      return( s0 );
   }

   public String format_vol_num_pages( )
   {
      String s0 , s1 , s2;
      s0 = field_or_null( volume );
      if( BuiltIn.empty( number ) <= 0 )
      {
         s0 = s0 + "(" + number + ")";
         if( BuiltIn.empty( volume ) > 0 )
         {
            s2 = BuiltIn.cite( bib );
            System.err.println( "Warning : there's a number but no volume in " + s2 + "." );
         }
      }
      if( BuiltIn.empty( pages ) <= 0 )
      {
         if( BuiltIn.empty( s0 ) > 0 )
         {
            s0 = format_pages( );
         }
         else
         {
            s1 = n_dashify( pages );
            s0 = s0 + ":" + s1;
         }
      }
      return( s0 );
   }

   public String format_chapter_pages( )
   {
      String s0 , s1;
      if( BuiltIn.empty( chapter ) > 0 )
      {
         s0 = format_pages( );
      }
      else
      {
         if( BuiltIn.empty( type ) > 0 )
         {
            s0 = "chapter";
         }
         else
         {
            s0 = BuiltIn.changeCase( type , "l" );
         }
         s0 = tie_or_space_connect( s0 , chapter );
         if( BuiltIn.empty( pages ) <= 0 )
         {
            s1 = format_pages( );
            s0 = s0 + ", " + s1;
         }
      }
      return( s0 );
   }

   public String format_in_ed_booktitle( )
   {
      String s0 , s1;
      if( BuiltIn.empty( booktitle ) > 0 )
      {
         s0 = "";
      }
      else
      {
         if( BuiltIn.empty( editor ) > 0 )
         {
            s1 = emphasize( booktitle );
            s0 = "In " + s1;
         }
         else
         {
            s1 = format_editors( );
            s0 = "In " + s1 + ", ";
            s1 = emphasize( booktitle );
            s0 = s0 + s1;
         }
      }
      return( s0 );
   }

   public void empty_misc_check( )
   {
      String s1;
      int i0 , i1 , i2 , i3 , i4 , i5;
      i0 = BuiltIn.empty( author );
      i1 = BuiltIn.empty( title );
      i2 = BuiltIn.empty( howpublished );
      i3 = BuiltIn.empty( month );
      i4 = BuiltIn.empty( year );
      i5 = BuiltIn.empty( note );
      i4 = and( new Cell( i4 ) , i5 );
      i3 = and( new Cell( i3 ) , i4 );
      i2 = and( new Cell( i2 ) , i3 );
      i1 = and( new Cell( i1 ) , i2 );
      i0 = and( new Cell( i0 ) , i1 );
      i1 = BuiltIn.empty( key );
      i1 = not( i1 );
      i0 = and( new Cell( i0 ) , i1 );
      if( i0 > 0 )
      {
         s1 = BuiltIn.cite( bib );
         System.err.println( "Warning : all relevant fields are empty in " + s1 + "." );
      }
   }

   public String format_thesis_type( Cell c0 )
   {
      String s0;
      if( BuiltIn.empty( type ) <= 0 )
      {
         s0 = BuiltIn.changeCase( type , "t" );
         c0 = new Cell( s0 );
      }
      s0 = c0.getString( );
      return( s0 );
   }

   public String format_tr_number( )
   {
      String s0;
      if( BuiltIn.empty( type ) > 0 )
      {
         s0 = "Technical Report";
      }
      else
      {
         s0 = type;
      }
      if( BuiltIn.empty( number ) > 0 )
      {
         s0 = BuiltIn.changeCase( s0 , "t" );
      }
      else
      {
         s0 = tie_or_space_connect( s0 , number );
      }
      return( s0 );
   }

   public String format_article_crossref( )
   {
      String s0 , s1;
      if( BuiltIn.empty( key ) > 0 )
      {
         if( BuiltIn.empty( journal ) > 0 )
         {
            s1 = BuiltIn.cite( bib );
            System.err.println( "Warning : need key or journal for " + s1 + " to crossref " + crossref + "." );
            s0 = "";
         }
         else
         {
            s0 = "In {\\em " + journal + "\\/}";
         }
      }
      else
      {
         s0 = "In " + key;
      }
      s0 = s0 + " \\cite{" + crossref + "}";
      return( s0 );
   }

   public String format_crossref_editor( )
   {
      String s0 , s1;
      int i1;
      s0 = BuiltIn.formatName( editor , 1 , "{vv~}{ll}" );
      i1 = BuiltIn.numnames( editor );
      if( i1 > 2 )
      {
         s0 = s0 + " et~al.";
      }
      else
      {
         i1 = 2 - i1;
         if( i1 <= 0 )
         {
            s1 = BuiltIn.formatName( editor , 2 , "{ff }{vv }{ll}{ jj}" );
            if( s1.compareTo( "others" ) == 0 )
            {
               s0 = s0 + " et~al.";
            }
            else
            {
               s1 = BuiltIn.formatName( editor , 2 , "{vv~}{ll}" );
               s0 = s0 + " and " + s1;
            }
         }
      }
      return( s0 );
   }

   public String format_book_crossref( )
   {
      String s0 , s1 , s2 , s3;
      int i1 , i2;
      if( BuiltIn.empty( volume ) > 0 )
      {
         s1 = BuiltIn.cite( bib );
         System.err.println( "Warning : empty volume in " + s1 + "'s crossref of " + crossref + "." );
         s0 = "In ";
      }
      else
      {
         s0 = tie_or_space_connect( "Volume" , volume );
         s0 = s0 + " of ";
      }
      i1 = BuiltIn.empty( editor );
      s2 = field_or_null( editor );
      s3 = field_or_null( author );
      i2 = BuiltIn.equal( s3 , s2 );
      i1 = or( new Cell( i1 ) , i2 );
      if( i1 > 0 )
      {
         if( BuiltIn.empty( key ) > 0 )
         {
            if( BuiltIn.empty( series ) > 0 )
            {
               s2 = BuiltIn.cite( bib );
               System.err.println( "Warning : need editor, key, or series for " + s2 + " to crossref " + crossref + "." );
            }
            else
            {
               s0 = s0 + "{\\em " + series + "\\/}";
            }
         }
         else
         {
            s0 = s0 + key;
         }
      }
      else
      {
         s1 = format_crossref_editor( );
         s0 = s0 + s1;
      }
      s0 = s0 + " \\cite{" + crossref + "}";
      return( s0 );
   }

   public String format_incoll_inproc_crossref( )
   {
      String s0 , s1 , s2;
      int i0 , i1;
      i0 = BuiltIn.empty( editor );
      s1 = field_or_null( editor );
      s2 = field_or_null( author );
      i1 = BuiltIn.equal( s2 , s1 );
      i0 = or( new Cell( i0 ) , i1 );
      if( i0 > 0 )
      {
         if( BuiltIn.empty( key ) > 0 )
         {
            if( BuiltIn.empty( booktitle ) > 0 )
            {
               s1 = BuiltIn.cite( bib );
               System.err.println( "Warning : need editor, key, or booktitle for " + s1 + " to crossref " + crossref + "." );
               s0 = "";
            }
            else
            {
               s0 = "In {\\em " + booktitle + "\\/}";
            }
         }
         else
         {
            s0 = "In " + key;
         }
      }
      else
      {
         s1 = format_crossref_editor( );
         s0 = "In " + s1;
      }
      s0 = s0 + " \\cite{" + crossref + "}";
      return( s0 );
   }

   public void article( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output_check( s0 , s1 , "author" );
      new_block( );
      s1 = format_title( );
      s0 = output_check( s0 , s1 , "title" );
      new_block( );
      if( BuiltIn.empty( crossref ) > 0 )
      {
         s1 = emphasize( journal );
         s0 = output_check( s0 , s1 , "journal" );
         s1 = format_vol_num_pages( );
         s0 = output( s0 , s1 );
         s1 = format_date( );
         s0 = output_check( s0 , s1 , "year" );
      }
      else
      {
         s1 = format_article_crossref( );
         s0 = output_nonnull( s0 , s1 );
         s1 = format_pages( );
         s0 = output( s0 , s1 );
      }
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void book( )
   {
      String s0 , s1 , s2;
      s0 = output_bibitem( );
      if( BuiltIn.empty( author ) > 0 )
      {
         s1 = format_editors( );
         s0 = output_check( s0 , s1 , "author and editor" );
      }
      else
      {
         s1 = format_authors( );
         s0 = output_nonnull( s0 , s1 );
         if( BuiltIn.empty( crossref ) > 0 )
         {
            s2 = editor;
            either_or_check( new Cell( "author and editor" ) , s2 );
         }
      }
      new_block( );
      s1 = format_btitle( );
      s0 = output_check( s0 , s1 , "title" );
      if( BuiltIn.empty( crossref ) > 0 )
      {
         s1 = format_bvolume( );
         s0 = output( s0 , s1 );
         new_block( );
         s1 = format_number_series( );
         s0 = output( s0 , s1 );
         new_sentence( );
         s0 = output_check( s0 , publisher , "publisher" );
         s0 = output( s0 , address );
      }
      else
      {
         new_block( );
         s1 = format_book_crossref( );
         s0 = output_nonnull( s0 , s1 );
      }
      s1 = format_edition( );
      s0 = output( s0 , s1 );
      s1 = format_date( );
      s0 = output_check( s0 , s1 , "year" );
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void booklet( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output( s0 , s1 );
      new_block( );
      s1 = format_title( );
      s0 = output_check( s0 , s1 , "title" );
      new_block_checkb( howpublished , address );
      s0 = output( s0 , howpublished );
      s0 = output( s0 , address );
      s1 = format_date( );
      s0 = output( s0 , s1 );
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void inbook( )
   {
      String s0 , s1 , s2;
      s0 = output_bibitem( );
      if( BuiltIn.empty( author ) > 0 )
      {
         s1 = format_editors( );
         s0 = output_check( s0 , s1 , "author and editor" );
      }
      else
      {
         s1 = format_authors( );
         s0 = output_nonnull( s0 , s1 );
         if( BuiltIn.empty( crossref ) > 0 )
         {
            s2 = editor;
            either_or_check( new Cell( "author and editor" ) , s2 );
         }
      }
      new_block( );
      s1 = format_btitle( );
      s0 = output_check( s0 , s1 , "title" );
      if( BuiltIn.empty( crossref ) > 0 )
      {
         s1 = format_bvolume( );
         s0 = output( s0 , s1 );
         s1 = format_chapter_pages( );
         s0 = output_check( s0 , s1 , "chapter and pages" );
         new_block( );
         s1 = format_number_series( );
         s0 = output( s0 , s1 );
         new_sentence( );
         s0 = output_check( s0 , publisher , "publisher" );
         s0 = output( s0 , address );
      }
      else
      {
         s1 = format_chapter_pages( );
         s0 = output_check( s0 , s1 , "chapter and pages" );
         new_block( );
         s1 = format_book_crossref( );
         s0 = output_nonnull( s0 , s1 );
      }
      s1 = format_edition( );
      s0 = output( s0 , s1 );
      s1 = format_date( );
      s0 = output_check( s0 , s1 , "year" );
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void incollection( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output_check( s0 , s1 , "author" );
      new_block( );
      s1 = format_title( );
      s0 = output_check( s0 , s1 , "title" );
      new_block( );
      if( BuiltIn.empty( crossref ) > 0 )
      {
         s1 = format_in_ed_booktitle( );
         s0 = output_check( s0 , s1 , "booktitle" );
         s1 = format_bvolume( );
         s0 = output( s0 , s1 );
         s1 = format_number_series( );
         s0 = output( s0 , s1 );
         s1 = format_chapter_pages( );
         s0 = output( s0 , s1 );
         new_sentence( );
         s0 = output_check( s0 , publisher , "publisher" );
         s0 = output( s0 , address );
         s1 = format_edition( );
         s0 = output( s0 , s1 );
         s1 = format_date( );
         s0 = output_check( s0 , s1 , "year" );
      }
      else
      {
         s1 = format_incoll_inproc_crossref( );
         s0 = output_nonnull( s0 , s1 );
         s1 = format_chapter_pages( );
         s0 = output( s0 , s1 );
      }
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void inproceedings( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output_check( s0 , s1 , "author" );
      new_block( );
      s1 = format_title( );
      s0 = output_check( s0 , s1 , "title" );
      new_block( );
      if( BuiltIn.empty( crossref ) > 0 )
      {
         s1 = format_in_ed_booktitle( );
         s0 = output_check( s0 , s1 , "booktitle" );
         s1 = format_bvolume( );
         s0 = output( s0 , s1 );
         s1 = format_number_series( );
         s0 = output( s0 , s1 );
         s1 = format_pages( );
         s0 = output( s0 , s1 );
         if( BuiltIn.empty( address ) > 0 )
         {
            new_sentence_checkb( organization , publisher );
            s0 = output( s0 , organization );
            s0 = output( s0 , publisher );
            s1 = format_date( );
            s0 = output_check( s0 , s1 , "year" );
         }
         else
         {
            s0 = output_nonnull( s0 , address );
            s1 = format_date( );
            s0 = output_check( s0 , s1 , "year" );
            new_sentence( );
            s0 = output( s0 , organization );
            s0 = output( s0 , publisher );
         }
      }
      else
      {
         s1 = format_incoll_inproc_crossref( );
         s0 = output_nonnull( s0 , s1 );
         s1 = format_pages( );
         s0 = output( s0 , s1 );
      }
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void conference( )
   {
      inproceedings( );
   }

   public void manual( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      if( BuiltIn.empty( author ) > 0 )
      {
         if( BuiltIn.empty( organization ) <= 0 )
         {
            s0 = output_nonnull( s0 , organization );
            s0 = output( s0 , address );
         }
      }
      else
      {
         s1 = format_authors( );
         s0 = output_nonnull( s0 , s1 );
      }
      new_block( );
      s1 = format_btitle( );
      s0 = output_check( s0 , s1 , "title" );
      if( BuiltIn.empty( author ) > 0 )
      {
         if( BuiltIn.empty( organization ) > 0 )
         {
            new_block_checka( address );
            s0 = output( s0 , address );
         }
      }
      else
      {
         new_block_checkb( organization , address );
         s0 = output( s0 , organization );
         s0 = output( s0 , address );
      }
      s1 = format_edition( );
      s0 = output( s0 , s1 );
      s1 = format_date( );
      s0 = output( s0 , s1 );
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void mastersthesis( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output_check( s0 , s1 , "author" );
      new_block( );
      s1 = format_title( );
      s0 = output_check( s0 , s1 , "title" );
      new_block( );
      s1 = format_thesis_type( new Cell( "Master's thesis" ) );
      s0 = output_nonnull( s0 , s1 );
      s0 = output_check( s0 , school , "school" );
      s0 = output( s0 , address );
      s1 = format_date( );
      s0 = output_check( s0 , s1 , "year" );
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void misc( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output( s0 , s1 );
      new_block_checkb( title , howpublished );
      s1 = format_title( );
      s0 = output( s0 , s1 );
      new_block_checka( howpublished );
      s0 = output( s0 , howpublished );
      s1 = format_date( );
      s0 = output( s0 , s1 );
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
      empty_misc_check( );
   }

   public void phdthesis( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output_check( s0 , s1 , "author" );
      new_block( );
      s1 = format_btitle( );
      s0 = output_check( s0 , s1 , "title" );
      new_block( );
      s1 = format_thesis_type( new Cell( "PhD thesis" ) );
      s0 = output_nonnull( s0 , s1 );
      s0 = output_check( s0 , school , "school" );
      s0 = output( s0 , address );
      s1 = format_date( );
      s0 = output_check( s0 , s1 , "year" );
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void proceedings( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      if( BuiltIn.empty( editor ) > 0 )
      {
         s0 = output( s0 , organization );
      }
      else
      {
         s1 = format_editors( );
         s0 = output_nonnull( s0 , s1 );
      }
      new_block( );
      s1 = format_btitle( );
      s0 = output_check( s0 , s1 , "title" );
      s1 = format_bvolume( );
      s0 = output( s0 , s1 );
      s1 = format_number_series( );
      s0 = output( s0 , s1 );
      if( BuiltIn.empty( address ) > 0 )
      {
         if( BuiltIn.empty( editor ) > 0 )
         {
            new_sentence_checka( publisher );
         }
         else
         {
            new_sentence_checkb( organization , publisher );
            s0 = output( s0 , organization );
         }
         s0 = output( s0 , publisher );
         s1 = format_date( );
         s0 = output_check( s0 , s1 , "year" );
      }
      else
      {
         s0 = output_nonnull( s0 , address );
         s1 = format_date( );
         s0 = output_check( s0 , s1 , "year" );
         new_sentence( );
         if( BuiltIn.empty( editor ) <= 0 )
         {
            s0 = output( s0 , organization );
         }
         s0 = output( s0 , publisher );
      }
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void techreport( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output_check( s0 , s1 , "author" );
      new_block( );
      s1 = format_title( );
      s0 = output_check( s0 , s1 , "title" );
      new_block( );
      s1 = format_tr_number( );
      s0 = output_nonnull( s0 , s1 );
      s0 = output_check( s0 , institution , "institution" );
      s0 = output( s0 , address );
      s1 = format_date( );
      s0 = output_check( s0 , s1 , "year" );
      new_block( );
      s0 = output( s0 , note );
      fin_entry( s0 );
   }

   public void unpublished( )
   {
      String s0 , s1;
      s0 = output_bibitem( );
      s1 = format_authors( );
      s0 = output_check( s0 , s1 , "author" );
      new_block( );
      s1 = format_title( );
      s0 = output_check( s0 , s1 , "title" );
      new_block( );
      s0 = output_check( s0 , note , "note" );
      s1 = format_date( );
      s0 = output( s0 , s1 );
      fin_entry( s0 );
   }

   public void default_type( )
   {
      misc( );
   }

   public String sortify( String s0 )
   {
      s0 = BuiltIn.purify( s0 );
      s0 = BuiltIn.changeCase( s0 , "l" );
      return( s0 );
   }

   public String chop_word( String s0 , int i1 , String s2 )
   {
      String s1;
      s = s2;
      len = i1;
      s1 = BuiltIn.substring( s2 , 1 , i1 );
      if( s1.compareTo( s0 ) == 0 )
      {
         s0 = BuiltIn.substring( s , len + 1 , global_max );
      }
      else
      {
         s0 = s;
      }
      return( s0 );
   }

   public String sort_format_names( String s0 )
   {
      String s1;
      int i1 , i2;
      s = s0;
      nameptr = 1;
      s0 = "";
      i1 = BuiltIn.numnames( s );
      numnames = i1;
      namesleft = i1;
      while( i1 > 0 )
      {
         if( nameptr > 1 )
         {
            s0 = s0 + "   ";
         }
         s1 = BuiltIn.formatName( s , nameptr , "{vv{ } }{ll{ }}{  ff{ }}{  jj{ }}" );
         t = s1;
         i1 = BuiltIn.equal( numnames , nameptr );
         i2 = BuiltIn.equal( "others" , s1 );
         i1 = and( new Cell( i1 ) , i2 );
         if( i1 > 0 )
         {
            s0 = s0 + "et al";
         }
         else
         {
            s1 = sortify( t );
            s0 = s0 + s1;
         }
         nameptr = nameptr + 1;
         i1 = namesleft - 1;
         namesleft = namesleft - 1;
      }
      return( s0 );
   }

   public String sort_format_title( String s0 )
   {
      String s2 , s4;
      t = s0;
      s4 = chop_word( "The " , 4 , s0 );
      s2 = chop_word( "An " , 3 , s4 );
      s0 = chop_word( "A " , 2 , s2 );
      s0 = sortify( s0 );
      s0 = BuiltIn.substring( s0 , 1 , global_max );
      return( s0 );
   }

   public String author_sort( )
   {
      String s0 , s1;
      if( BuiltIn.empty( author ) > 0 )
      {
         if( BuiltIn.empty( key ) > 0 )
         {
            s1 = BuiltIn.cite( bib );
            System.err.println( "Warning : to sort, need author or key in " + s1 + "." );
            s0 = "";
         }
         else
         {
            s0 = sortify( key );
         }
      }
      else
      {
         s0 = sort_format_names( author );
      }
      return( s0 );
   }

   public String author_editor_sort( )
   {
      String s0 , s1;
      if( BuiltIn.empty( author ) > 0 )
      {
         if( BuiltIn.empty( editor ) > 0 )
         {
            if( BuiltIn.empty( key ) > 0 )
            {
               s1 = BuiltIn.cite( bib );
               System.err.println( "Warning : to sort, need author, editor, or key in " + s1 + "." );
               s0 = "";
            }
            else
            {
               s0 = sortify( key );
            }
         }
         else
         {
            s0 = sort_format_names( editor );
         }
      }
      else
      {
         s0 = sort_format_names( author );
      }
      return( s0 );
   }

   public String author_organization_sort( )
   {
      String s0 , s1;
      if( BuiltIn.empty( author ) > 0 )
      {
         if( BuiltIn.empty( organization ) > 0 )
         {
            if( BuiltIn.empty( key ) > 0 )
            {
               s1 = BuiltIn.cite( bib );
               System.err.println( "Warning : to sort, need author, organization, or key in " + s1 + "." );
               s0 = "";
            }
            else
            {
               s0 = sortify( key );
            }
         }
         else
         {
            s0 = chop_word( "The " , 4 , organization );
            s0 = sortify( s0 );
         }
      }
      else
      {
         s0 = sort_format_names( author );
      }
      return( s0 );
   }

   public String editor_organization_sort( )
   {
      String s0 , s1;
      if( BuiltIn.empty( editor ) > 0 )
      {
         if( BuiltIn.empty( organization ) > 0 )
         {
            if( BuiltIn.empty( key ) > 0 )
            {
               s1 = BuiltIn.cite( bib );
               System.err.println( "Warning : to sort, need editor, organization, or key in " + s1 + "." );
               s0 = "";
            }
            else
            {
               s0 = sortify( key );
            }
         }
         else
         {
            s0 = chop_word( "The " , 4 , organization );
            s0 = sortify( s0 );
         }
      }
      else
      {
         s0 = sort_format_names( editor );
      }
      return( s0 );
   }

   public void presort( )
   {
      String s0 , s1;
      int i0 , i1;
      s0 = BuiltIn.type( bib );
      i0 = BuiltIn.equal( "book" , s0 );
      s1 = BuiltIn.type( bib );
      i1 = BuiltIn.equal( "inbook" , s1 );
      i0 = or( new Cell( i0 ) , i1 );
      if( i0 > 0 )
      {
         s0 = author_editor_sort( );
      }
      else
      {
         s0 = BuiltIn.type( bib );
         if( s0.compareTo( "proceedings" ) == 0 )
         {
            s0 = editor_organization_sort( );
         }
         else
         {
            s0 = BuiltIn.type( bib );
            if( s0.compareTo( "manual" ) == 0 )
            {
               s0 = author_organization_sort( );
            }
            else
            {
               s0 = author_sort( );
            }
         }
      }
      s1 = field_or_null( year );
      s1 = sortify( s1 );
      s0 = s0 + "    " + s1 + "    ";
      s1 = field_or_null( title );
      s1 = sort_format_title( s1 );
      s0 = BuiltIn.substring( s0 + s1 , 1 , entry_max );
      sort_key = s0;
   }

   public void initialize_longest_label( )
   {
      longest_label = "";
      number_label = 1;
      longest_label_width = 0;
   }

   public void longest_label_pass( )
   {
      String s0;
      int i0;
      s0 = String.valueOf( number_label );
      label = s0;
      number_label = number_label + 1;
      i0 = s0.length( );
      i0 = i0 - longest_label_width;
      if( i0 > 0 )
      {
         longest_label = label;
         i0 = label.length( );
         longest_label_width = i0;
      }
   }

   public void begin_bib( )
   {
      String s0;
      s0 = bib.getPreamble( );
      if( BuiltIn.empty( s0 ) <= 0 )
      {
         s0 = bib.getPreamble( );
         outputBib += s0;
         outputBib += "\n";
      }
      outputBib += "\\begin{thebibliography}{" + longest_label + "}";
      outputBib += "\n";
   }

   public void end_bib( )
   {
      outputBib += "\n";
      outputBib += "\\end{thebibliography}";
      outputBib += "\n";
   }

}

