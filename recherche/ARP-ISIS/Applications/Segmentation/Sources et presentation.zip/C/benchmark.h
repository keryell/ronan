#ifndef _BENCHMARK_H_
#define _BENCHMARK_H_

void bench_start( void );
float bench_read( void );
void bench_print( const char *Msg );

#endif
