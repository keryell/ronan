#ifndef _VIDEODEV_H_
#define _VIDEODEV_H_


void do_video_copy_EDRAM(void);
void do_video_reverse(void);
void do_segmentation( void );

#endif