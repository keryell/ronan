#ifndef _COMM_H_
#define _COMM_H_

#define COMPORT_IN	4
#define COMPORT_OUT	0

#endif